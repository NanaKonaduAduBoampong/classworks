import java.util.Scanner;
public class Exceptionn
{
public static void main(String[] args)
{
Scanner sc ;
sc = new Scanner (System.in);
System.out.println( "Enter your name" );
String myName = sc.next();
System.out.println( "Your name is " +myName);
}

}