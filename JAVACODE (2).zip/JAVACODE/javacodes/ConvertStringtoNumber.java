import java.util.Scanner;
public class ConvertStringtoNumber {

    public static void main(String[] args) {
        try {
Scanner cstn = new Scanner ( System.in);
System.out.println("Enter value");
            // intentional error
            String s = cstn.next();
            int i = Integer.parseInt(s);

            // this line of code will never be reached
            System.out.println("int value = " + i);
        }
        catch (NumberFormatException nfe) {
            System.out.println( " Cannot convert a string to an integer");
        }
    }

}