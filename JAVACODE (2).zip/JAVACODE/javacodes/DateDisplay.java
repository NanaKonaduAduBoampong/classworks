
import java.util.Date;
import java.text.SimpleDate
public class DateDisplay
{
	public static void main( String[] args )
	{

	Date d = new Date();
	System .out.println ( d.toString ());
	
	SimpleDateFormat format = new SimpleDateFormat( "yyyy/MM/dd");
	String dateString = format.format ( d);
	Date date = format.parse("2019/02/25");
	
	}

}
