public class PhoneMaker
{
	public static void main (String[] args)
	{
	
	}
}