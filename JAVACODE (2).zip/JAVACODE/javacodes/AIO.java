public class AOI
{
	public static void main ( Strings [] args)
	{
		int[] xValues = {3,7,2,4,9};

		for ( int i =0; i<=xValues.length; i++)

		{
			System.out.println ( xValues[i] )
		}
	}
}