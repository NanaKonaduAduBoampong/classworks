class bishal { 
  
} class Geeks { 
  
} class MyClass { 
public static void main(String[] args) 
    { 
        Object o = class.forName(args[0]).newInstance(); 
        System.out.println("Class created for" + o.getClass().getName()); 
    } 