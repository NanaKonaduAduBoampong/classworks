public class AOI
{
	public static void main (String [] args)
	{
		int[] xValues = {3,7,2,4,9};

		for ( int i =0; i<=xValues.length; i++)

		{
			try {
				System.out.println ( xValues[i] );
			      }

			catch (ArrayIndexOutOfBoundsException ex)
			{
				System.out.println( "Array index " + i +"for xValues does not exist" );	
			}
		}
	}
}