import java.util.Scanner;

public class Exception{
 public static void main(String[] args)
{

	Scanner  sc = new Scanner(System.in);
	System.out.println("Enter value for numerator");
	int nValue = sc.nextInt();
	System.out.println("Ener value for denominator");
	int dValue = sc.nextInt();
	double quotient = nValue/(double)dValue;
	System.out.println("The quotient of" + nValue +"and"+dValue + "is" + quotient);
	
}
}