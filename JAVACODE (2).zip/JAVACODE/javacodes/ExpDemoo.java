import  java.util.Scanner;
public class ExpDemoo
{
	public static void main (String[] args)
	{
		Scanner sc= new Scanner(Sytem.in);
		System.out.print ( "Enter value for numerator" );
		int nValue = sc.nextInt();
		System.out.println( "Enter value for denominator");
		int dvalue = sc.nextInt();
		double quotient = nValue/(double)dValue;
 		System.out.println( "The quotient of "  nValue  "and"  dValue "is"+quotient);
	}

}