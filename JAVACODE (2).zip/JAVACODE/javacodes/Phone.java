public class Phone
{
	private String manufacturer;
	private String colour;
	private double screenSize;
	private String phoneModel;
	private double price;
	private int memorySize;
	private int batteryCapacity;


	public boolean makeCall(String contactNumber )
	{
		//Write some code here

		boolean callStatus = false;
		
		return callStatus; 
	}

	
	public void receiveCalls()
	{
	
	}

	public void captureImage()
	{
	
	}

	
	public void captueImage( int delay)
	{
	
	}

}