import java.util.GregorianCalendar;
import java.util.Calendar;

public class DemoOverload
{
	public static void main(String[] args)
{
	int month=7;
	int day=1;
	int year=2014;
	
	displayDate(month);
	displayDate(month,day);
	displayDate(month,day,year);
}
	public static void displayDate(int mm)
{
	GregorianCalendar gcal=new GregorianCalendar();
	System.out.println("DATE:" + mm +"/"+   gcal.get(Calendar.DATE) +"/"+  gcal.get(Calendar.YEAR));
}
public static void displayDate(int mm, int dd)
{
	GregorianCalendar gcal=new GregorianCalendar();
	System.out.println("DATE:" + mm + "/"+dd+"/"+  gcal.get(Calendar.YEAR));
}
public static void displayDate(int mm, int dd,int yy)
{
	GregorianCalendar gcal=new GregorianCalendar();
	System.out.println("DATE:" + mm + "/"+dd+"/"+yy);
}
}
	

	
