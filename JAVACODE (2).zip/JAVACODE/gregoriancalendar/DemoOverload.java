import java.util.GregorianCalendar;
import java.util.Calendar;
public class DemoOverload
{	
	public static int day = 0;
	public static int month = 0;
	public static int year = 2014;


		public  static void displayDate(int month )
		{
			GregorianCalendar gcal = new GregorianCalendar( );
			System.out.println( month +"/ " +gcal.get(Calendar.DATE)+" /"+ year);
		}

		public static void displayDate(int  month, int day)
		{
			GregorianCalendar gcal = new GregorianCalendar( );
			System.out.println( month+"/ " +day+" /"+year);
		}

		public static void displayDate( int month, int  day, int year )
		{
			GregorianCalendar gcal = new GregorianCalendar( );
			System.out.println( month +"/ " +day+" /"+ year );
		}

		public static void main( String args[])
		{
			displayDate(12);
		}

}